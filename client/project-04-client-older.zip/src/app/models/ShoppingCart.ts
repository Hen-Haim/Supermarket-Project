export class ShoppingCart {
    public constructor(
        public shoppingCartId?: number,
        public idUser?: number,
    ){}

}